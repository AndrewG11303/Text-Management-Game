/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package itsc.pkg1213.project.pkg2;

/**
 *
 * @author Andrew
 */

/**
 * The GeneratorType enum represents the different types of generators available in the game.
 * Each constant in this enum corresponds to a specific type of resource generator.
 */
public enum GeneratorType {
     // Enum constants representing different types of generators
    LUMBER_MILL, IRON_MINE, STONE_MINE, FARM
    
}
